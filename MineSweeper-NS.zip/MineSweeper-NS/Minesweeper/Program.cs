﻿namespace Minesweeper
{
    public class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Welcome to Minesweeper!\n");

                int sizeofGrid = Minesweeper.CalculateGridSize();
                int maxMines = (int)(sizeofGrid * sizeofGrid * 0.35);
                int numMines = Minesweeper.CountMinesNumber(maxMines);

                char[,] minefield = Minesweeper.Initializer(sizeofGrid);
                Minesweeper.SetMines(minefield, numMines);

                var minesweeper = new Minesweeper();
                minesweeper.StartGame(minefield, sizeofGrid, numMines);

                Console.WriteLine("Press any key to play again...");
                Console.ReadKey();
            }
        }
    }
}
