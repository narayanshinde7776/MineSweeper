﻿namespace Minesweeper.Tests
{
    public class MinesweeperTests
    {
        [Fact]
        public void SetSelectedCells_ValidInput_ParsesSuccessfully()
        {
            // Arrange
            var gridSize = 3;
            var minesweeper = new Minesweeper();

            // Act
            var result = minesweeper.SetSelectedCells("A2", gridSize, out var row, out var col);

            // Assert
            Assert.True(result);
            Assert.Equal(0, row);
            Assert.Equal(1, col);
        }

        [Fact]
        public void StartGame_MineDetonated_GameOver()
        {
            // Arrange
            var minefield = new char[,] { { 'X' } };
            var gridSize = 1;
            var numMines = 1;
            var minesweeper = new Minesweeper();
            Console.SetIn(new StringReader("A1"));

            // Act
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                minesweeper.StartGame(minefield, gridSize, numMines);
                var result = sw.ToString().Trim();

                // Assert
                Assert.Contains("Oh no, you detonated a mine! Game over.", result);
            }
        }

        [Fact]
        public void StartGame_WinGame_CongratulationsMessage()
        {
            // Arrange
            var minefield = new char[,] { { '0', '1' }, { '1', '1' } };
            var gridSize = 2;
            var numMines = 0;
            var minesweeper = new Minesweeper();

            Console.SetIn(new StringReader("A1"));

            // Act
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                minesweeper.StartGame(minefield, gridSize, numMines);
                var result = sw.ToString().Trim();

                // Print the captured output for inspection
                Console.WriteLine(result);
                // Assert
                Assert.Contains("Congratulations, you have won the game!", result);
            }
        }
    }

}
